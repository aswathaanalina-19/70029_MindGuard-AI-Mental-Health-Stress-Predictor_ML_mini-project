import { GoogleGenAI, Type } from "@google/genai";
import { AssessmentData, PredictionResult, StressLevel } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function predictStress(data: AssessmentData, simulatedScenario?: string): Promise<PredictionResult> {
  const prompt = `
    Analyze the following mental health assessment data and predict the user's stress level.
    Return a detailed analysis and actionable recommendations.
    
    Assessment Data:
    - Sleep Hours: ${data.sleepHours}h
    - Workload (1-10): ${data.workLoad}
    - Mood: ${data.mood}
    - Social Interaction (1-10): ${data.socialInteraction}
    - Physical Activity: ${data.physicalActivity} min/day
    - Recent Stressors: ${data.recentStressors}
    ${simulatedScenario ? `\nSimulated Context: ${simulatedScenario}` : ""}
    
    You must return your response in JSON format according to this schema:
    {
      "level": "Low" | "Moderate" | "High" | "Critical",
      "score": number (0-100),
      "analysis": "string detailing the reasoning",
      "recommendations": ["string", "string", ...]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            level: { type: Type.STRING, enum: Object.values(StressLevel) },
            score: { type: Type.NUMBER },
            analysis: { type: Type.STRING },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["level", "score", "analysis", "recommendations"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Prediction failed:", error);
    throw new Error("Could not analyze stress data. Please try again.");
  }
}

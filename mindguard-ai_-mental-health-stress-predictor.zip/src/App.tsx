/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import AssessmentFlow from './components/AssessmentFlow';
import InfoOverlay from './components/InfoOverlay';

export default function App() {
  const [activeOverlay, setActiveOverlay] = React.useState<'methodology' | 'ethics' | 'contact' | null>(null);

  return (
    <div className="min-h-screen">
      <nav className="fixed top-0 left-0 w-full z-50 px-8 py-6 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-8 h-8 bg-olive rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-xs">M</span>
          </div>
          <span className="font-serif text-2xl font-medium tracking-tight">MindGuard AI</span>
        </div>
        
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-ink/60 uppercase tracking-widest pointer-events-auto">
          <button 
            onClick={() => setActiveOverlay('methodology')}
            className="hover:text-olive transition-colors cursor-pointer"
          >
            Methodology
          </button>
          <button 
            onClick={() => setActiveOverlay('ethics')}
            className="hover:text-olive transition-colors cursor-pointer"
          >
            Ethics
          </button>
          <button 
            onClick={() => setActiveOverlay('contact')}
            className="hover:text-olive transition-colors cursor-pointer"
          >
            Contact
          </button>
        </div>

        <button className="px-5 py-2 rounded-full border border-olive/20 text-olive text-sm font-medium hover:bg-olive hover:text-white transition-all pointer-events-auto">
          Lab Access
        </button>
      </nav>

      <InfoOverlay 
        isOpen={!!activeOverlay} 
        onClose={() => setActiveOverlay(null)} 
        type={activeOverlay} 
      />
      
      <main className="pt-20">
        <AssessmentFlow />
      </main>

      <footer className="py-12 px-8 border-t border-ink/5 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-serif text-lg">Stress Prediction Labs v1.2</h4>
            <p className="text-xs text-ink/40 font-mono">ENCRYPTED ANALYSIS • SYSTEM READY</p>
          </div>
          <div className="flex gap-6 text-sm text-ink/40">
            <a href="#">Privacy Protocol</a>
            <a href="#">Simulated Environment Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}


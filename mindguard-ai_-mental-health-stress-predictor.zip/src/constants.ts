import { Scenario } from "./types.ts";

export const SCENARIOS: Scenario[] = [
  {
    id: "student-finals",
    name: "Student in Finals Week",
    description: "High academic pressure, irregular sleep, and social isolation due to studying.",
    data: {
      sleepHours: 4,
      workLoad: 9,
      mood: "Anxious and overwhelmed, feeling like there's never enough time.",
      socialInteraction: 2,
      physicalActivity: 10,
      recentStressors: "Upcoming calculus exam worth 40% of the grade."
    }
  },
  {
    id: "med-shift",
    name: "Medical Resident on Double Shift",
    description: "Physical exhaustion, high-stakes decision making, and minimal rest.",
    data: {
      sleepHours: 3,
      workLoad: 10,
      mood: "Numb but focused, occasional irritability.",
      socialInteraction: 5,
      physicalActivity: 200,
      recentStressors: "Consecutive 12-hour shifts in the ER."
    }
  },
  {
    id: "remote-burnout",
    name: "Remote Worker (Burnout)",
    description: "Blurred boundaries, lack of physical movement, and routine monotony.",
    data: {
      sleepHours: 7,
      workLoad: 8,
      mood: "Lethargic, lack of motivation, feeling disconnected.",
      socialInteraction: 3,
      physicalActivity: 0,
      recentStressors: "Endless Zoom meetings and isolation."
    }
  },
  {
    id: "parent-toddler",
    name: "Parent of a Newborn",
    description: "Fragmented sleep, high emotional labor, and constant caregiving.",
    data: {
      sleepHours: 5,
      workLoad: 7,
      mood: "Joyful but physically drained, brain fog.",
      socialInteraction: 4,
      physicalActivity: 30,
      recentStressors: "Sleep regression and balancing household tasks."
    }
  }
];

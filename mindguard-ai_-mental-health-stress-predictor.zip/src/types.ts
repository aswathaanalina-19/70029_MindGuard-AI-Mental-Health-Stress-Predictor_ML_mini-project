export enum StressLevel {
  LOW = 'Low',
  MODERATE = 'Moderate',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface AssessmentData {
  sleepHours: number;
  workLoad: number; // 1-10
  mood: string;
  socialInteraction: number; // 1-10
  physicalActivity: number; // minutes per day
  recentStressors: string;
}

export interface PredictionResult {
  level: StressLevel;
  score: number; // 0-100
  analysis: string;
  recommendations: string[];
  simulationContext?: string;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  data: AssessmentData;
}

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Sparkles, Activity, ShieldCheck, ArrowRight, RotateCcw } from 'lucide-react';
import { AssessmentData, PredictionResult, Scenario } from '../types';
import { SCENARIOS } from '../constants';
import { predictStress } from '../services/gemini';
import { cn } from '../lib/utils';

export default function AssessmentFlow() {
  const [step, setStep] = React.useState<'intro' | 'form' | 'loading' | 'results'>('intro');
  const [formData, setFormData] = React.useState<AssessmentData>({
    sleepHours: 7,
    workLoad: 5,
    mood: '',
    socialInteraction: 5,
    physicalActivity: 30,
    recentStressors: ''
  });
  const [result, setResult] = React.useState<PredictionResult | null>(null);
  const [activeScenario, setActiveScenario] = React.useState<string | null>(null);

  const handleStart = () => setStep('form');
  
  const handleScenarioSelect = (scenario: Scenario) => {
    setFormData(scenario.data);
    setActiveScenario(scenario.name);
    setStep('form');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep('loading');
    try {
      const prediction = await predictStress(formData, activeScenario || undefined);
      setResult(prediction);
      setStep('results');
    } catch (error) {
      alert("Analysis failed. Please check your connection.");
      setStep('form');
    }
  };

  const handleReset = () => {
    setStep('intro');
    setResult(null);
    setActiveScenario(null);
    setFormData({
      sleepHours: 7,
      workLoad: 5,
      mood: '',
      socialInteraction: 5,
      physicalActivity: 30,
      recentStressors: ''
    });
  };

  return (
    <div className="min-h-screen py-12 px-4 flex items-center justify-center">
      <AnimatePresence mode="wait">
        {step === 'intro' && (
          <motion.div
            key="intro"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="max-w-3xl text-center space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-olive/10 text-olive font-medium">
              <Brain className="w-5 h-5" />
              <span>MindGuard Intelligence</span>
            </div>
            <h1 className="text-6xl md:text-7xl font-serif leading-tight">
              Predicting Stress <span className="italic font-light">Before</span> It Peaks.
            </h1>
            <p className="text-xl text-ink/70 max-w-2xl mx-auto">
              Our AI analyzes your behavioral patterns and provides predictive insights to safeguard your mental well-being. Start a real-time assessment or explore pre-defined scenarios.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <button
                onClick={handleStart}
                className="w-full sm:w-auto px-8 py-4 bg-olive text-white rounded-full font-medium hover:bg-olive/90 transition-all flex items-center justify-center gap-2"
              >
                Start New Assessment <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="pt-12">
              <p className="text-sm font-medium uppercase tracking-widest text-ink/40 mb-6">Explore Simulated Lab Scenarios</p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {SCENARIOS.map((scenario) => (
                  <button
                    key={scenario.id}
                    onClick={() => handleScenarioSelect(scenario)}
                    className="p-6 rounded-2xl bg-white border border-olive/10 hover:border-olive/30 hover:bg-white/80 transition-all text-left group"
                  >
                    <h3 className="font-sans font-semibold text-lg mb-2 group-hover:text-olive">{scenario.name}</h3>
                    <p className="text-xs text-ink/60 line-clamp-2">{scenario.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="w-full max-w-2xl bg-white p-10 rounded-[2.5rem] shadow-xl shadow-olive/5 border border-olive/5"
          >
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl">Assessment Insights</h2>
                {activeScenario && (
                  <span className="px-3 py-1 bg-olive/10 text-olive text-xs font-bold rounded-full uppercase tracking-tighter">
                    Scenario: {activeScenario}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Sleep Hours ({formData.sleepHours}h)</label>
                  <input
                    type="range"
                    min="2"
                    max="12"
                    step="0.5"
                    value={formData.sleepHours}
                    onChange={(e) => setFormData({ ...formData, sleepHours: parseFloat(e.target.value) })}
                    className="w-full accent-olive"
                  />
                </div>

                <div className="space-y-4">
                  <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Workload (1-10)</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={formData.workLoad}
                    onChange={(e) => setFormData({ ...formData, workLoad: parseInt(e.target.value) })}
                    className="w-full accent-olive"
                  />
                </div>

                <div className="space-y-4">
                  <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Social Interaction (1-10)</label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={formData.socialInteraction}
                    onChange={(e) => setFormData({ ...formData, socialInteraction: parseInt(e.target.value) })}
                    className="w-full accent-olive"
                  />
                </div>

                <div className="space-y-4">
                  <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Physical Activity (min/day)</label>
                  <input
                    type="number"
                    value={formData.physicalActivity}
                    onChange={(e) => setFormData({ ...formData, physicalActivity: parseInt(e.target.value) })}
                    className="w-full p-3 rounded-xl border border-olive/20 focus:ring-2 focus:ring-olive/20 focus:border-olive outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Current Mood (Describe how you feel)</label>
                <textarea
                  required
                  rows={3}
                  value={formData.mood}
                  onChange={(e) => setFormData({ ...formData, mood: e.target.value })}
                  placeholder="I feel exhausted but determined..."
                  className="w-full p-4 rounded-2xl border border-olive/20 focus:ring-2 focus:ring-olive/20 focus:border-olive outline-none transition-all resize-none"
                />
              </div>

              <div className="space-y-4">
                <label className="block text-sm font-medium text-ink/60 uppercase tracking-wider">Recent Stressors</label>
                <input
                  required
                  type="text"
                  value={formData.recentStressors}
                  placeholder="Major project deadline, moving house, etc."
                  onChange={(e) => setFormData({ ...formData, recentStressors: e.target.value })}
                  className="w-full p-4 rounded-2xl border border-olive/20 focus:ring-2 focus:ring-olive/20 focus:border-olive outline-none transition-all"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-6 py-4 rounded-2xl border border-ink/10 text-ink/60 hover:bg-ink/5 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-6 py-4 bg-olive text-white rounded-2xl font-semibold hover:bg-olive/90 shadow-lg shadow-olive/20 transition-all flex items-center justify-center gap-2"
                >
                  Analyze Stress Patterns <Sparkles className="w-5 h-5" />
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {step === 'loading' && (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center space-y-6"
          >
            <div className="relative">
              <div className="w-24 h-24 border-4 border-olive/10 border-t-olive rounded-full animate-spin mx-auto"></div>
              <Brain className="w-8 h-8 text-olive absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-serif">Simulating Cognitive Load</h2>
              <p className="text-ink/60 animate-pulse">Running stress prediction models based on behavioral markers...</p>
            </div>
          </motion.div>
        )}

        {step === 'results' && result && (
          <motion.div
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-10 rounded-[2.5rem] shadow-xl space-y-8 border border-olive/5">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-text-muted text-xs font-bold uppercase tracking-widest mb-2">Predictive Outcome</h2>
                    <h1 className="text-5xl font-serif">Stress Status: {result.level}</h1>
                  </div>
                  <div className={cn(
                    "px-6 py-3 rounded-2xl text-white font-bold text-xl",
                    result.level === 'Low' && "bg-emerald-500",
                    result.level === 'Moderate' && "bg-amber-500",
                    result.level === 'High' && "bg-orange-500",
                    result.level === 'Critical' && "bg-rose-500",
                  )}>
                    {result.score}%
                  </div>
                </div>

                <div className="p-6 bg-olive/5 rounded-3xl border border-olive/10 min-h-[150px]">
                  <p className="text-lg leading-relaxed text-ink/80 italic">
                    {result.analysis}
                  </p>
                </div>

                <div className="space-y-6">
                  <h3 className="text-xl font-semibold flex items-center gap-2">
                    <ShieldCheck className="text-olive w-6 h-6" /> Actionable Mitigation Strategy
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {result.recommendations.map((rec, i) => (
                      <div key={i} className="p-4 bg-warm-bg rounded-2xl border border-ink/5 flex gap-3 text-sm">
                        <span className="flex-shrink-0 w-6 h-6 bg-olive text-white rounded-lg flex items-center justify-center font-bold">{i+1}</span>
                        <span className="text-ink/70">{rec}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-olive text-white p-8 rounded-[2.5rem] shadow-xl h-fit">
                <Activity className="w-10 h-10 mb-6 opacity-80" />
                <h3 className="text-2xl font-serif mb-6">Expert Evaluation Verdict</h3>
                <div className="space-y-6 text-sm text-white/90">
                  <div>
                    <span className="block font-bold mb-1 opacity-60 uppercase tracking-tighter">Objective ✅</span>
                    <p>Real-time stress prediction using sentiment analysis and lifestyle markers.</p>
                  </div>
                  <div>
                    <span className="block font-bold mb-1 opacity-60 uppercase tracking-tighter">Innovation 🔧</span>
                    <p>Cross-referencing physiological estimates with subjective emotional feedback.</p>
                  </div>
                  <div>
                    <span className="block font-bold mb-1 opacity-60 uppercase tracking-tighter">Future Scope 🚀</span>
                    <p>Direct biometric API integration (Apple Health/Fitbit) for autonomous prediction.</p>
                  </div>
                </div>
              </div>

              <button
                onClick={handleReset}
                className="w-full p-6 bg-white rounded-[2rem] border border-ink/10 hover:bg-ink/5 transition-all font-semibold flex items-center justify-center gap-2 shadow-sm"
              >
                <RotateCcw className="w-5 h-5" /> Start New Simulation
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

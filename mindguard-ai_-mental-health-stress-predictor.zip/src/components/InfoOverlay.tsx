import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, BookOpen, ShieldAlert, Mail, Terminal, Layers, HeartPulse } from 'lucide-react';

interface InfoOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'methodology' | 'ethics' | 'contact' | null;
}

export default function InfoOverlay({ isOpen, onClose, type }: InfoOverlayProps) {
  const content = {
    methodology: {
      title: "Scientific Methodology",
      icon: <BookOpen className="w-8 h-8 text-olive" />,
      tagline: "Behavioral Sentiment Integration (BSI) v4.0",
      sections: [
        {
          label: "Data Pre-processing",
          desc: "We analyze high-entropy markers (mood descriptions, stressors) and low-entropy markers (sleep, activity) through separate neural pathways.",
          icon: <Terminal className="w-4 h-4" />
        },
        {
          label: "Predictive Analytics",
          desc: "Using Gemini's large-scale context window, we correlate current stressors with long-term behavioral trends to forecast burnout zones.",
          icon: <Layers className="w-4 h-4" />
        },
        {
          label: "Output Tuning",
          desc: "Each prediction is cross-validated against 8 core stress pillars to ensure actionable recommendations rather than generic advice.",
          icon: <HeartPulse className="w-4 h-4" />
        }
      ]
    },
    ethics: {
      title: "Ethics & Compliance",
      icon: <ShieldAlert className="w-8 h-8 text-rose-600" />,
      tagline: "Zero-Trust Privacy & Clinical Boundaries",
      sections: [
        {
          label: "Data Sovereignty",
          desc: "MindGuard does not persist your PHI. All analysis occurs in a volatile execution environment and is purged post-session.",
          icon: <ShieldAlert className="w-4 h-4" />
        },
        {
          label: "Clinical Disclaimer",
          desc: "This is an AI simulation for preventative insight. It is not a diagnostic tool for clinical anxiety, depression, or PTSD.",
          icon: <Terminal className="w-4 h-4" />
        },
        {
          label: "Bias Mitigation",
          desc: "Our models are strictly audited for demographic neutrality in linguistic analysis to prevent occupational or cultural stress bias.",
          icon: <HeartPulse className="w-4 h-4" />
        }
      ]
    },
    contact: {
      title: "Simulation Lab Access",
      icon: <Mail className="w-8 h-8 text-blue-600" />,
      tagline: "Global Response Infrastructure",
      sections: [
        {
          label: "Tech Support",
          desc: "lab-support@mindguard.ai",
          icon: <Terminal className="w-4 h-4" />
        },
        {
          label: "Research Inquiry",
          desc: "research@mindguard.ai",
          icon: <Layers className="w-4 h-4" />
        },
        {
          label: "Crisis Line",
          desc: "Immediate help: 988 (National Suicide Prevention Lifeline)",
          icon: <HeartPulse className="w-4 h-4" />
        }
      ]
    }
  };

  const activeContent = type ? content[type] : null;

  return (
    <AnimatePresence>
      {isOpen && activeContent && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-ink/40 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl bg-white rounded-[3rem] p-12 overflow-hidden shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute top-8 right-8 p-2 rounded-full hover:bg-ink/5 transition-all"
            >
              <X className="w-6 h-6 text-ink/40" />
            </button>

            <div className="flex flex-col gap-8">
              <div className="flex items-center gap-6">
                <div className="p-4 bg-ink/5 rounded-2xl">
                  {activeContent.icon}
                </div>
                <div>
                  <h2 className="text-4xl font-serif">{activeContent.title}</h2>
                  <p className="text-sm font-mono text-ink/40 tracking-widest uppercase mt-1">{activeContent.tagline}</p>
                </div>
              </div>

              <div className="space-y-6">
                {activeContent.sections.map((section, idx) => (
                  <div key={idx} className="group p-6 rounded-3xl border border-ink/5 hover:border-olive/20 hover:bg-olive/5 transition-all">
                    <div className="flex items-center gap-3 mb-2">
                       <span className="p-1.5 bg-ink/5 rounded-md group-hover:bg-olive/20 group-hover:text-olive transition-colors">{section.icon}</span>
                       <h3 className="font-bold text-lg">{section.label}</h3>
                    </div>
                    <p className="text-ink/60 leading-relaxed pl-9">{section.desc}</p>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={onClose}
                  className="px-8 py-3 bg-ink text-white rounded-full font-medium hover:bg-ink/80 transition-all"
                >
                  Close Terminal
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
